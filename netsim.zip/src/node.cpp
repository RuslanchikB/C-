#include "node.h"

#include <iostream>
#include <cstring>
#include <stdexcept>

//**** PUBLIC API ****//

Node::Node(uint32_t addr) : _stack(this) {
    _addr = addr;
}

void Node::processIncome() {
    if(_income.empty()) {
        return;
    }

    Node* src_node = _income.front().first;
    NetPackage data = _income.front().second;
    _income.pop();

    if(data.dst_ip == _addr || (data.dst_ip == BROADCAST_ADDR && data.src_ip != getAddr())) {
        std::cout << NetPackage::ipToStr(getAddr())
                  << ": Receive package from: " 
                  << NetPackage::ipToStr(data.src_ip)
                  << " with TTL="
                  << (int)data.ttl
                  << std::endl;

        _stack.processPackage(data, src_node);
        
        // Do not rebraodcaset package if this node was source
        if(data.dst_ip == BROADCAST_ADDR && data.src_ip != getAddr()) {
            _outcome.push(std::make_pair(src_node, data));
        }
    } else {
        _outcome.push(std::make_pair(src_node, data));
    }
}

void Node::processOutcome() {
    if(_outcome.empty()) {
        return;
    }

    Node* src_node = _outcome.front().first;
    NetPackage data = _outcome.front().second;
    _outcome.pop();

    if(data.ttl == 0) {
        std::cout << NetPackage::ipToStr(getAddr())
                  << ": Received package with TTL=0. Dropping"
                  << std::endl;
        return;
    }
    
    data.ttl--;


    if(data.dst_ip == BROADCAST_ADDR) {
        for(Node* n: _connections) {
            if(n != src_node) {
                std::cout << NetPackage::ipToStr(getAddr())
                        << ": Broadcasting package from "
                        << NetPackage::ipToStr(data.src_ip)
                        << " to "
                        << NetPackage::ipToStr(n->getAddr())
                        << std::endl;
                n->receive(data, this);
            }
        }
    } else if(_routes.find(data.dst_ip) != _routes.end()) {
        Node* route_node = _routes[data.dst_ip].second;
        std::cout << NetPackage::ipToStr(getAddr())
                  << ": Routing package from: "
                  << NetPackage::ipToStr(data.src_ip)
                  << " to: "
                  << NetPackage::ipToStr(data.dst_ip)
                  << " over: "
                  << NetPackage::ipToStr(route_node->getAddr())
                  << std::endl; 
        route_node->receive(data, this);
    } else {
        std::cout << NetPackage::ipToStr(getAddr()) 
                  << ": IP address "
                  << NetPackage::ipToStr(data.dst_ip)
                  << " is not in the routing table. Dropping package" 
                  << std::endl;
    }
}

void Node::tick() {
    if(getEnabled()) {
        // Process income/outcome messages
        processIncome();
    }

    processOutcome();
}

void Node::addConnection(Node* node) {
    //Add bidiretional connection
    addConnectedNode(node);
    node->addConnectedNode(this);
}

void Node::receive(NetPackage data, Node* interface) {
    _income.push(std::make_pair(interface, data));
}

void Node::send(uint32_t addr, uint8_t data[32], uint8_t ttl) {
    NetPackage p;
    p.src_ip = _addr;
    p.dst_ip = addr;

    p.ttl = ttl;
    memcpy(p.payload, data, sizeof(NetPackage::payload));
    
    std::cout << NetPackage::ipToStr(getAddr())
              << ": Send package from: "
              << NetPackage::ipToStr(p.src_ip)
              << " to: "
              << NetPackage::ipToStr(p.dst_ip)
              << std::endl;

    send(p);
}

void Node::send(NetPackage data) {
    _outcome.push(std::make_pair(nullptr, data));
}

uint32_t Node::getAddr() const {
    return _addr;
}

void Node::addRoute(uint32_t addr, Node* port, uint8_t priority) {
    if(_connections.find(port) == _connections.end()) {
        std::cout << "Failed to add route: Host " 
                  << NetPackage::ipToStr(port->getAddr())
                  << " Not connected to "
                  << NetPackage::ipToStr(getAddr())
                  << std::endl;
    }
    
    if(_routes.find(addr) != _routes.end()) {
        if(_routes[addr].first >= priority) {
            return;
        }
    }
    std::cout << NetPackage::ipToStr(getAddr())
                    << ": Got route to: "
                    << NetPackage::ipToStr(addr)
                    << " over: "
                    << NetPackage::ipToStr(port->getAddr())
                    << std::endl;
                    
    _routes[addr] = std::make_pair(priority, port);   
}

void Node::delRoute(uint32_t addr) {
    if(addr == BROADCAST_ADDR) {
        _routes.clear();
        return;
    }
    _routes.erase(addr);
}

ProtocolStack Node::getProtocolStack() {
    return _stack;
}

void Node::setEnabled(bool enabled) {
    std::cout << NetPackage::ipToStr(getAddr())
              << ": Set " << ((enabled) ? "enabled":"disabled")
              << std::endl;
    _enabled = enabled;
}

bool Node::getEnabled() {
    return _enabled;
}


//**** PRIVATE API ****//

void Node::addConnectedNode(Node* node) {
    _connections.insert(node);
}