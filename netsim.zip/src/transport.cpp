#include "transport.h"
#include "protoimpl.h"
#include "node.h"
#include <cmath>
#include <cstring>
#include <iostream>

enum MessageType: uint8_t {
    DATA_END = 1,
    DATA_CONTINUE = 2
};

struct TransportMessage {
    uint8_t protocolid;     // Just to simplify parsing
    MessageType type;
    uint8_t reserved;       // For alignment purposes
    uint8_t fragmentSize;
    uint8_t data[28];
};


TransportProto::TransportProto(ProtocolStack* st) {
    _stack = st;
}
   
void TransportProto::sendTransportMessage(
    uint32_t addr, 
    const uint8_t* msg, 
    size_t msg_len
) {
    size_t packCount = ceil((double)msg_len/sizeof(TransportMessage::data));

    for(size_t i = 0; i < packCount-1; ++i) {
        TransportMessage packet;
        packet.protocolid = TRANSPORT;
        packet.type = DATA_CONTINUE;
        packet.fragmentSize = sizeof(packet.data);
        memcpy(packet.data, msg + i*sizeof(packet.data), sizeof(packet.data));

        _stack->getOwner()->send(addr, (uint8_t*)&packet, 255);
    }

    TransportMessage packet;
    packet.protocolid = TRANSPORT;
    packet.type = DATA_END;
    packet.fragmentSize = msg_len - (packCount-1)*sizeof(packet.data);
    memcpy(packet.data, msg+(packCount-1)*sizeof(packet.data), 
            packet.fragmentSize);

    _stack->getOwner()->send(addr, (uint8_t*)&packet, 255);
}

void TransportProto::processMessage(NetPackage p) {
    TransportMessage* msg = (TransportMessage*)p.payload;

    for(int i = 0; i < msg->fragmentSize; ++i) {
        _input_buff[p.src_ip].push_back(msg->data[i]);
    }

    if(msg->type == DATA_END) {
        std::cout << NetPackage::ipToStr(_stack->getOwner()->getAddr())
                  << ": Got message from "
                  << NetPackage::ipToStr(p.src_ip) 
                  << ": "
                  << std::string(_input_buff[p.src_ip].begin(), _input_buff[p.src_ip].end())
                  << std::endl;
        _input_buff[p.src_ip].clear();
    }
}