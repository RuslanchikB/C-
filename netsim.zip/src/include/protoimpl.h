#ifndef PROTOIMPL_H
#define PROTOIMPL_H

#include "netpackage.h"
#include "transport.h"

enum ProtocolId: uint8_t {
    ICMP = 1,
    TRANSPORT = 2
};

class Node;

class ProtocolStack {
public:
    ProtocolStack(Node* n);

    /**
     * @brief Process incoming message callback
     * 
     * @param p message to process
     * @param srcPort source port (node) of message
     */
    void processPackage(NetPackage p, Node* srcPort);

    /**
     * @brief Setup network connection (send package about power on)
     * 
     */
    void powerOn();

    /**
     * @brief Deinit network connection (send package about power off)
     * 
     */
    void powerOff();

    /**
     * @brief Get the Owner object
     * 
     * @return Node* 
     */
    Node* getOwner();

    /**
     * @brief Get the Transport object
     * 
     * @return TransportProto 
     */
    TransportProto getTransport();

private: 
    Node* _owner_node;
    TransportProto _transport;
};

#endif // PROTOIMPL_H
