#ifndef NODE_H
#define NODE_H

#include <cstdint>
#include <queue>
#include <set>
#include <map>
#include "netpackage.h"
#include "protoimpl.h"

class Node {
public:
    Node(uint32_t addr);

    /**
     * @brief Process packages in queue
     * 
     */
    void tick();

    /**
     * @brief Add new connected node
     * 
     * @param node Node to be connected
     */
    void addConnection(Node* node);

    /**
     * @brief Send a data to the input queue of this node
     * 
     * @param data Data to be sent
     * @param interface Data interface source
     */
    void receive(NetPackage data, Node* interface);

    /**
     * @brief Send data package from this node to another
     * 
     * @param addr Destination node address
     * @param data Data to be sent
     * @param len length of data
     */
    void send(uint32_t addr, uint8_t data[32], uint8_t ttl);

    /**
     * @brief Send network layer package from this node to another
     * 
     * @param p Network layer package
     */
    void send(NetPackage p);

    /**
     * @brief Get the ip address of node
     * 
     * @return uint32_t ip address
     */
    uint32_t getAddr() const;

    /**
     * @brief Add route to certain ip address
     * 
     * @param addr Host address to add route for
     * @param port Connected port to route over
     * @param priority Priority of the route (higher-priority routes
     *  overviretes routes with a lower one)
     */
    void addRoute(uint32_t addr, Node* port, uint8_t priority);

    /**
     * @brief 
     * 
     * @param addr 
     */
    void delRoute(uint32_t addr);

    /**
     * @brief Get the Protocol Stack object
     * 
     * @return ProtocolStack 
     */
    ProtocolStack getProtocolStack();

    /**
     * @brief Set the Enabled object
     * 
     * @param enabled 
     */
    void setEnabled(bool enabled);

    /**
     * @brief Get the Enabled object
     * 
     * @return true 
     * @return false 
     */
    bool getEnabled();

private:

    /**
     * @brief Add node to connection container
     * 
     * @param node 
     */
    void addConnectedNode(Node* node);

    void processIncome();
    void processOutcome();
    
private:
    std::set<Node*> _connections;
    std::queue<std::pair<Node*, NetPackage>> _income;
    std::queue<std::pair<Node*, NetPackage>> _outcome;
    std::map<uint32_t, std::pair<uint8_t,Node*>> _routes;

    ProtocolStack _stack;

    uint32_t _addr;

    bool _enabled;
};

#endif // NODE_H
