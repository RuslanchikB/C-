#ifndef TRANSPORT_H
#define TRANSPORT_H

#include <map>
#include <vector>
#include <cstdint>
#include "netpackage.h"


class ProtocolStack;

class TransportProto {
public:
    TransportProto(ProtocolStack* st);
    /**
     * @brief Send message over transport protocol
     * 
     * @param addr destination address
     * @param msg message to be sent
     * @param msg_len length of message
     */
    void sendTransportMessage(uint32_t addr, const uint8_t* msg, size_t msg_len);

    /**
     * @brief Process input message
     * 
     * @param p message to be processed
     */
    void processMessage(NetPackage p);

private: 
    ProtocolStack* _stack;
    std::map<uint32_t, std::vector<uint8_t>> _input_buff;
};

#endif // TRANSPORT_H
