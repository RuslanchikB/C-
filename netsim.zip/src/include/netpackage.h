#ifndef NETPACKAGE_H
#define NETPACKAGE_H


#include <cstdint>
#include <string>
#include <sstream>
#include <cstdio>

#define BROADCAST_ADDR 0xffffffff

struct NetPackage {
    uint32_t src_ip;
    uint32_t dst_ip;
    uint8_t ttl;

    uint8_t payload[32];

    static std::string ipToStr(uint32_t addr) {
        std::stringstream ss;
        ss << (addr>>(32-8) & 0xff) << "." << (addr>>(32-16) & 0xff) << "."
           << (addr>>(32-24) & 0xff) << "."  << (addr>>(32-32) & 0xff);

        return ss.str();
    } 

    static uint32_t strToIp(std::string addr) {
        uint8_t octets[4];

        sscanf(addr.c_str(), "%hhd.%hhd.%hhd.%hhd", 
                                &octets[0], 
                                &octets[1],
                                &octets[2],
                                &octets[3]);

        uint32_t uaddr =    ((octets[0] & 0xff) << 32-8)  |
                            ((octets[1] & 0xff) << 32-16) |
                            ((octets[2] & 0xff) << 32-24) |
                            ((octets[3] & 0xff) << 32-32);

        return uaddr;
    }

    operator std::string() {
        std::stringstream ss;
        ss << "====================================\n"
           << "Source ip: " << ipToStr(src_ip) << ";\n"
           << "Destination ip: " << ipToStr(dst_ip) << ";\n"
           << "TTL: " << (int)ttl << ";\n"
           << "====================================";

        return ss.str();
    }
};


#endif // NETPACKAGE_H