#include <iostream>
#include <cstring>
#include "node.h"
#include <thread>
#include <chrono>
#include <exception>
#include <sstream>
#include <atomic>

#define ITEMS_CNT(array) (sizeof(array)/sizeof(array[0]))

static void ticker_cb(Node* n, size_t node_cnt, bool& exit) {
    while(true) {
        if(exit) {
            break;
        }
        for(int i = 0; i < node_cnt; ++i) {
            n[i].tick();
        }
    }
}

bool cmpcmd(std::string s1, std::string s2) {
    return strncmp(s1.c_str(), s2.c_str(), s2.length());
}

std::vector<std::string> splitcmd(std::string s) {
    std::string delim = " ";
    size_t pos = s.find(delim);
    size_t initialPos = 0;
    std::vector<std::string> strs;

    // Decompose statement
    while( pos != std::string::npos ) {
        strs.push_back( s.substr( initialPos, pos - initialPos ) );
        initialPos = pos + 1;

        pos = s.find( delim, initialPos );
    }

    // Add the last one
    strs.push_back( s.substr( initialPos, std::min( pos, s.size() ) - initialPos + 1 ) );

    return strs;
}

void print_help() {
    std::cout << std::endl;
    std::cout << "  Available commands:" << std::endl;
    std::cout << "exit or quit -- Exit program" << std::endl;
    std::cout << "[address] on -- Enable the node" << std::endl;
    std::cout << "[address] off -- Disable the node" << std::endl;
    std::cout << "[address] send [destination address] [message]" << std::endl;  
    std::cout << std::endl;     
}

int main() {


    std::cout << "  Network topology:         " << std::endl
              << "   n1                 n2    " << std::endl
              << "  [*]----------------[*]    " << std::endl
              << "   |\\                 |    " << std::endl
              << "   | \\                |    " << std::endl
              << "   |  \\n3             |    " << std::endl
              << "   |  [*]            [*] n4 " << std::endl
              << "   |  /               |     " << std::endl
              << "   | /                |     " << std::endl
              << "   |/ n5              | n6  " << std::endl
              << "  [*]----------------[*]    " << std::endl;

    print_help();

    Node n[] = {
        Node(NetPackage::strToIp("0.0.0.1")),
        Node(NetPackage::strToIp("0.0.0.2")),
        Node(NetPackage::strToIp("0.0.0.3")),
        Node(NetPackage::strToIp("0.0.0.4")),
        Node(NetPackage::strToIp("0.0.0.5")),
        Node(NetPackage::strToIp("0.0.0.6"))
    };

    // Setup connections
    n[1-1].addConnection(&n[2-1]);
    n[1-1].addConnection(&n[3-1]);
    n[1-1].addConnection(&n[5-1]);
    n[2-1].addConnection(&n[4-1]);
    n[3-1].addConnection(&n[5-1]);
    n[4-1].addConnection(&n[6-1]);
    n[5-1].addConnection(&n[6-1]);


    // Update routing table
    std::cout << "Power on..." << std::endl;
    for(int i = 0; i < ITEMS_CNT(n); ++i) {
        n[i].getProtocolStack().powerOn();
    }
    bool stop = false;
    std::thread ticker_th(ticker_cb, n, ITEMS_CNT(n), std::ref<bool>(stop));

    while(true) {
        std::string cmd;
        getline(std::cin, cmd);
        std::vector<std::string> tokens = splitcmd(cmd);

        if(tokens.empty()) {
            continue;
        }

        try {
            if(tokens.at(0) == "exit" ||
               tokens.at(0) == "quit") {
                break;
            }

            uint32_t src_addr = NetPackage::strToIp(tokens.at(0))-1; 
            if(src_addr > ITEMS_CNT(n)) {
                print_help();
                continue;
            }

            if(tokens.at(1) == "on") {
                n[src_addr].getProtocolStack().powerOn();
            } else if(tokens.at(1) == "off") {
                n[src_addr].getProtocolStack().powerOff();
            } else if (tokens.at(1) == "send") {
                uint32_t dst_addr = NetPackage::strToIp(tokens[2]);
                std::stringstream ss; 
                for(int i = 3; i < tokens.size(); ++i) {
                    ss << tokens[i] << " ";
                }

                std::string msg = ss.str();
                n[src_addr].getProtocolStack().getTransport().sendTransportMessage(
                    dst_addr, (const uint8_t*)msg.c_str(), msg.size() 
                );
            } else {
                std::cout << "Invalid command " << cmd << std::endl;
            }

        } catch(...) {
            print_help();
        }
    }

    stop = true;
    ticker_th.join();

    return 0;
}