#include "protoimpl.h"
#include <iostream>
#include <string>
#include <cstdint>
#include <cstring>

#include "node.h"



enum ICMPMessageType: uint8_t {
    POWER_ON = 0,
    POWER_OFF = 1
};

struct ICMPPacket {
    ProtocolId id = ICMP;
    ICMPMessageType type;
};

ProtocolStack::ProtocolStack(Node* n) : _transport(this) {
    _owner_node = n;
}

void ProtocolStack::processPackage(NetPackage p, Node* srcPort) {
    /* std::cout <<  NetPackage::ipToStr(_owner_node->getAddr())
              << ": New package!" << std::endl 
              << (std::string)p 
              << std::endl; */

    ProtocolId* id = (ProtocolId*)p.payload;

    if(*id == ICMP) {
        ICMPPacket* ipack = (ICMPPacket*)p.payload;
        if(ipack->type == POWER_ON) {
            //Update routing table
            _owner_node->addRoute(p.src_ip, srcPort, p.ttl);
        } else if(ipack->type == POWER_OFF) {
            // Node was dropped, delete all routes, broadcast power on message
            _owner_node->delRoute(BROADCAST_ADDR);
            powerOn();
        }
    } else if(*id == TRANSPORT) {
        _transport.processMessage(p);
    }
}

void ProtocolStack::powerOn() {
    ICMPPacket p;
    p.type = POWER_ON;
    _owner_node->setEnabled(true);

    uint8_t data[32] = {0};
    memcpy(data, &p, sizeof(p));

    _owner_node->send(BROADCAST_ADDR, data, 3);
}

void ProtocolStack::powerOff() {
    ICMPPacket p;
    p.type = POWER_OFF;
    _owner_node->setEnabled(false);

    uint8_t data[32] = {0};
    memcpy(data, &p, sizeof(p));

    _owner_node->send(BROADCAST_ADDR, data, 3);
}

Node* ProtocolStack::getOwner() {
    return _owner_node;
}

TransportProto ProtocolStack::getTransport() {
    return _transport;
}